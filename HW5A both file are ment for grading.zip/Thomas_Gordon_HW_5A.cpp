//////////////////////////////////////////////////////
//Name: Thomas Gordon								//
//Date: 11-16-17									//
//Assignment: HomeWork 5A							//
//class: COP2000 intro to computer programming (c++)//
//////////////////////////////////////////////////////
/*alright i am going to be honest and try and amuse you this is not the real
project homework so i tried to do something similar to the project and used functions
to call most of the areas that are used in the program... like the last project the original project that
you wanted us to do i will give along with this program so look at that along with this program too they
both have the same concept "find the missing number" in mind
along with this one hopefully i could get a grade for this and the other original code as well
when i say original i mean code that was meant to be for the module five in blackboard along with this program
which compiles and runs fin but the original program does not or i at least havent tested it
although this code dosent have arrays i put arrays in the other code
the point of having two programs is so that i could get a decent grade and learn something
any ways hopfully i could get a good grade for this project and boost my grade a little bit.*/

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;
void randomizer();
void loop();
void exit();

int main(void)
{
	randomizer();
	loop();
	exit();

	system("pause");
	return 0;
}

void randomizer()
{
	srand(time(NULL)); // To not have the same numbers over and over again.
}

void loop()
{
	while (true)
	{
		// Main loop.
		// Initialize and allocate.
		int number = rand() % 99 + 2; // System number is stored in here.
		int guess; // User guess is stored in here.
		int tries = 0; // Number of tries is stored here.
		char answer; // User answer to question is stored here.

					 //cout << number << "\n"; // Was used for debug...

		while (true)
		{
			// Get user number loop.
			// Get number.
			cout << "Enter a number between 1 and 100 (" << 20 - tries << " tries left): ";
			cin >> guess;
			cin.ignore();

			// Check is tries are taken up.
			if (tries >= 20)
			{
				break;
			}

			// Check number.
			if (guess > number)
			{
				cout << "Too high! Try again." << endl;
			}
			else if (guess < number)
			{
				cout << "Too low! Try again." << endl;
			}
			else
			{
				break;
			}

			// If not number, increment tries.
			tries++;
		}

		// Check for tries.
		if (tries >= 20)
		{
			cout << "You ran out of tries!" << endl << endl;
		}
		else
		{
			// Or, user won.
			cout << "Congratulations!! " << endl;
			cout << "You got the right number in " << tries << " tries!\n";
		}

		while (true)
		{
			// Loop to ask user is he/she would like to play again.
			// Get user response.
			cout << "Would you like to play again (Y/N)? ";
			cin >> answer;
			cin.ignore();

			// Check if proper response.
			if (answer == 'n' || answer == 'N' || answer == 'y' || answer == 'Y')
			{
				break;
			}
			else
			{
				cout << "Please enter \'Y\' or \'N\'...\n";
			}
		}

		// Check user's input and run again or exit;
		if (answer == 'n' || answer == 'N')
		{
			cout << "Thank you for playing!";
			break;
		}
		else
		{
			cout << endl << endl << endl;
		}
	}
}

void exit()
{
	// Safely exit.
	cout << endl << endl << " Enter anything to exit... ";
	cin.ignore();
}