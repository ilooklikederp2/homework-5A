//////////////////////////////////////////////////////
//Name: Thomas Gordon								//
//Date: 11-16-17									//
//Assignment: HomeWork 5A							//
//class: COP2000 intro to computer programming (c++)//
//////////////////////////////////////////////////////
#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <cmath>
#include <string>
#include <ctime>
using namespace std;

//function prototyping 
int beginGame(int playedBoard[]);
void displayBoard(int board[][3]);
bool testWinner(int ans, int boardNum, int ansBoard[]);
void instructions();

int main()
{
	int playedBoard[3] = { 14, 15, 8 };
	int board1 = 1,
		board2 = 2,
		board3 = 3,
		quit = 0;


	int board1[4][3] = { 38, 11, 83,
		15, 6, 33,
		10, 2, 20,
		86, NULL, 95 };

	int board2[4][3] = { 28, 10, 55,
		89, 17, 98,
		22, 4, 31,
		69, NULL, 78 };

	int board3[4][3] = { 90, 9, 45,
		66, 12, 48,
		34, 7, 70,
		44, NULL, 26 };

	int answerboard_array[3] = { 14, 15, 8 };

	int usedBoards[3] = { NULL };
	beginGame(playedBoard);
	instructions();
	displayBoard(board);

	if (board1 = 1)
	{
		cout << board1 << endl;
	}
	else if (board2 = 2)
	{
		cout << board2 << endl;
	}
	else if (board3 = 3)
	{
		cout << board3 << endl;
	}
	else
	{
		cout << quit << "thanks for playing bye ;p" << endl;
	}

	if (board1 != 2 || 3)
	{
		cout << board1 << endl;
	}

	if (board2 != 1 || 3)
	{
		cout << board2 << endl;
	}

	if (board3 != 1 || 2)
	{
		cout << board3 << endl;
	}


	system("pause");
	return 0;
}

int beginGame(int playedBoard[3])
{
	int boardnumbers = 1,
		boardnumbers = 2,
		boardnumbers = 3;
	srand(time(0));
	for (int boardnumbers = 1; boardnumbers < 3; boardnumbers++)
	{
		cout << 1 + (rand() % 3) << endl;
	}

	int playerboard[3] = { boardnumbers, NULL };
}


void displayBoard(int board[][3])
{

}

bool testWinner(int ans, int boardNum, int ansBoard[])
{

}

void instructions()
{
	cout << "*****************************************************************" << endl;
	cout << "MISSING NUMBERS GAME" << endl;
	cout << "A fun brain game�" << endl;
	cout << "Please Enter a whole number to guess the missing number�" << endl;
	cout << "Program Developed by : Thomas Gordon" << endl;
	cout << "*****************************************************************" << endl;

}
